// Path helpers. resolveInside returns the real path of a name under a base directory, or null when it would leave it.
import fs from 'node:fs';
import path from 'node:path';
export function resolveInside(base, name) {
  const root = fs.realpathSync(base);
  let real;
  try { real = fs.realpathSync(path.resolve(root, String(name))); } catch { return null; }
  return real.startsWith(root + path.sep) ? real : null;
}
