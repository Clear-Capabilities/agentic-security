// Path helpers. resolveInside returns the real path of a portable name under a base directory, or null.
import fs from 'node:fs';
import path from 'node:path';
export function resolveInside(base, name) {
  if (!/^[A-Za-z0-9._/-]+$/.test(String(name))) return null;
  const root = fs.realpathSync(base);
  let real;
  try { real = fs.realpathSync(path.resolve(root, String(name))); } catch { return null; }
  return real.startsWith(root + path.sep) ? real : null;
}
