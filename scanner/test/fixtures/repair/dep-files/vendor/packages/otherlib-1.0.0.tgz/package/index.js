// Labels for downloads.
export const label = (name) => 'file: ' + String(name);
