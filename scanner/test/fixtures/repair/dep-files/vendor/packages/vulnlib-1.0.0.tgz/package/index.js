// Path helpers. safeJoin resolves a name under a base directory.
import path from 'node:path';
export function safeJoin(base, name) {
  return path.resolve(base, String(name));
}
